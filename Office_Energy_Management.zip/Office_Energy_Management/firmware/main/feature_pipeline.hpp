#pragma once

#include <array>

#include "sensors.hpp"

constexpr size_t kFeatureVectorSize = 16;

using FeatureVector = std::array<float, kFeatureVectorSize>;

class FeaturePipeline {
public:
    void build(const SensorReadings &readings, FeatureVector &out_features);

private:
    float normalize(float value, float min, float max) const;
};



