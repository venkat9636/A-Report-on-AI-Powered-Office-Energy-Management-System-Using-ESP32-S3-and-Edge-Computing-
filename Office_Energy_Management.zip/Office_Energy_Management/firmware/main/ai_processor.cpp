#include "ai_processor.hpp"

#include <cstring>

#include "ai_model_data.h"
#include "esp_log.h"
#include "tensorflow/lite/micro/all_ops_resolver.h"
#include "tensorflow/lite/micro/micro_error_reporter.h"
#include "tensorflow/lite/micro/micro_interpreter.h"

namespace {
constexpr char kTag[] = "AiProcessor";
constexpr size_t kTensorArenaSize = 60 * 1024;
alignas(16) static uint8_t tensor_arena[kTensorArenaSize];

std::unique_ptr<tflite::MicroInterpreter> interpreter;
tflite::MicroErrorReporter micro_reporter;
const tflite::Model *model = nullptr;
TfLiteTensor *input = nullptr;
}  // namespace

esp_err_t AiProcessor::init() {
    model = tflite::GetModel(g_health_model_data);
    if (!model) {
        ESP_LOGE(kTag, "Model pointer null");
        return ESP_FAIL;
    }
    static tflite::AllOpsResolver resolver;
    interpreter.reset(new tflite::MicroInterpreter(model, resolver,
                                                   tensor_arena,
                                                   kTensorArenaSize,
                                                   &micro_reporter));
    if (!interpreter) {
        ESP_LOGE(kTag, "Interpreter allocation failed");
        return ESP_FAIL;
    }
    TfLiteStatus allocate_status = interpreter->AllocateTensors();
    if (allocate_status != kTfLiteOk) {
        ESP_LOGE(kTag, "Tensor allocation failed");
        return ESP_FAIL;
    }
    input = interpreter->input(0);
    initialized_ = true;
    return ESP_OK;
}

esp_err_t AiProcessor::infer(const FeatureVector &features,
                             InferenceResult &result) {
    if (!initialized_) {
        ESP_LOGE(kTag, "Not initialized");
        return ESP_ERR_INVALID_STATE;
    }
    if (input->bytes < features.size() * sizeof(float)) {
        ESP_LOGE(kTag, "Input tensor too small");
        return ESP_FAIL;
    }
    memcpy(input->data.f, features.data(),
           features.size() * sizeof(float));
    TfLiteStatus status = interpreter->Invoke();
    if (status != kTfLiteOk) {
        ESP_LOGE(kTag, "Invoke failed");
        return ESP_FAIL;
    }
    TfLiteTensor *output = interpreter->output(0);
    const int classes = std::min<int>(4, output->dims->data[1]);
    result.winning_index = 0;
    float max_prob = -1;
    for (int i = 0; i < classes; ++i) {
        float prob = output->data.f[i];
        result.probabilities[i] = prob;
        if (prob > max_prob) {
            max_prob = prob;
            result.winning_index = i;
        }
    }
    return ESP_OK;
}



