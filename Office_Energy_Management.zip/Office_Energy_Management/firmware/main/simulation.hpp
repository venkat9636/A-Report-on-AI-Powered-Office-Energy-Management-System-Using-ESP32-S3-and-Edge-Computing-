#pragma once

#include <array>
#include <cstdint>

#include "sensors.hpp"

class SensorSimulator {
public:
    esp_err_t init();
    esp_err_t sample(SensorReadings &out_readings);

private:
    float time_s_ = 0.0f;
    float occupancy_state_ = 0.0f;  // Occupancy level
    float motion_state_ = 0.0f;

    float clamp01(float value) const;
};
