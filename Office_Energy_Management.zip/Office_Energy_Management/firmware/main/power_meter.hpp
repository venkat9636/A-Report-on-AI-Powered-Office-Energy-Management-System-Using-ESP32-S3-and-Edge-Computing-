#pragma once

#include <cstdint>
#include <cstddef>

/**
 * @brief INA219 Power Metering Driver
 * 
 * High-side current monitor with integrated voltage measurement
 * 32V, ±3.2A max, I2C interface
 */
class PowerMeter {
public:
    /**
     * @brief Initialize INA219 power meter on specified I2C bus
     * @param i2c_port I2C port number (I2C_NUM_0 or I2C_NUM_1)
     * @param sda_pin SDA pin number
     * @param scl_pin SCL pin number
     * @param i2c_addr INA219 I2C address (0x40-0x4F depending on A0/A1)
     */
    PowerMeter(int i2c_port, int sda_pin, int scl_pin, uint8_t i2c_addr = 0x40);
    
    /**
     * @brief Initialize the power meter
     * Sets up I2C communication, configures measurement ranges
     * @return true if successful, false if device not found
     */
    bool init();
    
    /**
     * @brief Read power metrics from the device
     * @param voltage_v Output: Bus voltage in volts
     * @param current_a Output: Current in amperes
     * @param power_w Output: Power in watts
     * @param power_factor Output: Power factor (0.0-1.0)
     * @param valid Output: Flag indicating measurement validity
     */
    void read_power(float& voltage_v, float& current_a, float& power_w, 
                    float& power_factor, bool& valid);
    
    /**
     * @brief Read diagnostic registers for harmonic content
     * @param thd_percent Output: Total harmonic distortion percentage
     * @param valid Output: Flag indicating measurement validity
     */
    void read_harmonic_content(float& thd_percent, bool& valid);
    
    /**
     * @brief Set measurement configuration
     * @param voltage_range Maximum bus voltage (16V or 32V)
     * @param adc_resolution Number of samples to average (9-12 bits)
     */
    void set_config(uint16_t voltage_range, uint8_t adc_resolution);

private:
    int i2c_port_;
    int sda_pin_;
    int scl_pin_;
    uint8_t i2c_addr_;
    
    // Calibration values
    float current_lsb_;  // Current least significant bit
    float power_lsb_;    // Power least significant bit
    uint16_t calibration_value_;
    
    // I2C communication
    bool write_register(uint8_t reg, uint16_t value);
    bool read_register(uint8_t reg, uint16_t& value);
    
    // Register addresses
    static constexpr uint8_t REG_CONFIG = 0x00;
    static constexpr uint8_t REG_SHUNT_VOLTAGE = 0x01;
    static constexpr uint8_t REG_BUS_VOLTAGE = 0x02;
    static constexpr uint8_t REG_POWER = 0x03;
    static constexpr uint8_t REG_CURRENT = 0x04;
    static constexpr uint8_t REG_CALIBRATION = 0x05;
};
