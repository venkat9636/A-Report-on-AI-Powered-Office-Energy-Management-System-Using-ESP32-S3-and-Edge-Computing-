#include "simulation.hpp"

#include <cmath>

#include "esp_timer.h"

namespace {
float randf() {
    return static_cast<float>(esp_random() % 10000) / 10000.0f;
}
}  // namespace

esp_err_t SensorSimulator::init() {
    time_s_ = 0.0f;
    occupancy_state_ = 0.0f;
    motion_state_ = 0.0f;
    return ESP_OK;
}

esp_err_t SensorSimulator::sample(SensorReadings &out_readings) {
    time_s_ += 0.2f;
    
    // Simulate occupancy patterns (people entering/leaving)
    if (randf() > 0.96f) {
        // Person enters room
        occupancy_state_ = std::min(1.0f, occupancy_state_ + 0.4f);
        motion_state_ = 0.8f;
    } else if (randf() > 0.98f && occupancy_state_ > 0.3f) {
        // Person leaves room
        occupancy_state_ = std::max(0.0f, occupancy_state_ - 0.5f);
        motion_state_ = 0.2f;
    } else {
        // Gradual decay
        occupancy_state_ *= 0.995f;
        motion_state_ *= 0.95f;
    }
    
    out_readings.occupancy_score = clamp01(occupancy_state_ + randf() * 0.1f);
    out_readings.motion_detection = clamp01(motion_state_ + randf() * 0.15f);
    
    // Light level: increases when occupied (lights on), decreases when empty
    const float base_light = 0.3f;  // Ambient/natural light
    out_readings.light_level = clamp01(base_light + occupancy_state_ * 0.6f + randf() * 0.1f);
    
    // Temperature: slight increase when occupied
    out_readings.temperature = 22.0f + occupancy_state_ * 2.0f + std::sin(time_s_ * 0.01f) * 1.0f + randf() * 0.5f;
    
    // Energy consumption: correlates with occupancy and light/appliance usage
    out_readings.energy_consumption = 50.0f + occupancy_state_ * 200.0f + out_readings.light_level * 100.0f + randf() * 20.0f;
    
    // Appliance state: aggregate of lights and appliances
    out_readings.appliance_state = clamp01(occupancy_state_ * 0.8f + out_readings.light_level * 0.5f);
    
    out_readings.occupancy_valid = true;
    out_readings.motion_valid = true;
    out_readings.light_valid = true;
    return ESP_OK;
}

float SensorSimulator::clamp01(float value) const {
    if (value < 0.0f) return 0.0f;
    if (value > 1.0f) return 1.0f;
    return value;
}
