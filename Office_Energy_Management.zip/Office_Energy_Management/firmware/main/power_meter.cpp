#include "power_meter.hpp"
#include "esp_log.h"
#include "driver/i2c.h"
#include <cmath>

static const char* TAG = "PowerMeter";

// INA219 Configuration constants
#define INA219_CONFIG_BVOLTAGERANGE_32V        (0x2000)
#define INA219_CONFIG_GAIN_8_320MV             (0x1800)
#define INA219_CONFIG_BADCRES_12BIT            (0x0018)
#define INA219_CONFIG_SADCRES_12BIT_1S_532US   (0x0184)
#define INA219_CONFIG_MODE_SANDBVOLT_CONTINUOUS (0x0007)

PowerMeter::PowerMeter(int i2c_port, int sda_pin, int scl_pin, uint8_t i2c_addr)
    : i2c_port_(i2c_port), sda_pin_(sda_pin), scl_pin_(scl_pin), 
      i2c_addr_(i2c_addr), current_lsb_(0.1f), power_lsb_(2.0f), 
      calibration_value_(4096) {}

bool PowerMeter::init() {
    ESP_LOGI(TAG, "Initializing INA219 power meter at address 0x%02X", i2c_addr_);
    
    // Configure I2C if not already done
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = sda_pin_,
        .scl_io_num = scl_pin_,
        .master = {.clk_speed = 100000},
        .clk_flags = 0,
    };
    
    i2c_param_config((i2c_port_num_t)i2c_port_, &conf);
    i2c_driver_install((i2c_port_num_t)i2c_port_, I2C_MODE_MASTER, 0, 0, 0);
    
    // Read config register to verify device is present
    uint16_t config;
    if (!read_register(REG_CONFIG, config)) {
        ESP_LOGE(TAG, "INA219 not found at address 0x%02X", i2c_addr_);
        return false;
    }
    
    ESP_LOGI(TAG, "INA219 found. Config register: 0x%04X", config);
    
    // Set configuration for 32V, 3.2A max
    // BusVoltageRange: 32V (bit 13)
    // Gain: ±320mV (bits 12-11)
    // Bus ADC: 12-bit (bits 8-7)
    // Shunt ADC: 12-bit, 532µs (bits 6-3)
    // Mode: Shunt and bus, continuous (bits 2-0)
    uint16_t ina219_config = INA219_CONFIG_BVOLTAGERANGE_32V |
                             INA219_CONFIG_GAIN_8_320MV |
                             INA219_CONFIG_BADCRES_12BIT |
                             INA219_CONFIG_SADCRES_12BIT_1S_532US |
                             INA219_CONFIG_MODE_SANDBVOLT_CONTINUOUS;
    
    if (!write_register(REG_CONFIG, ina219_config)) {
        ESP_LOGE(TAG, "Failed to write INA219 configuration");
        return false;
    }
    
    // Set calibration register for 3.2A max measurement
    // Calibration = 0.04096 / (Current_LSB * Rshunt)
    // Using Rshunt = 0.1 ohm, Current_LSB = 10mA
    calibration_value_ = 4096;  // 0.04096 / (0.01 * 0.1) = 4096
    
    if (!write_register(REG_CALIBRATION, calibration_value_)) {
        ESP_LOGE(TAG, "Failed to write INA219 calibration");
        return false;
    }
    
    current_lsb_ = 0.01f;  // 10 mA
    power_lsb_ = 0.2f;     // 200 mW
    
    ESP_LOGI(TAG, "INA219 initialization complete");
    return true;
}

bool PowerMeter::write_register(uint8_t reg, uint16_t value) {
    uint8_t data[3] = {reg, (uint8_t)(value >> 8), (uint8_t)value};
    esp_err_t ret = i2c_master_write_to_device((i2c_port_num_t)i2c_port_, 
                                                i2c_addr_, data, 3, 100 / portTICK_PERIOD_MS);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to write register 0x%02X: %s", reg, esp_err_to_name(ret));
        return false;
    }
    return true;
}

bool PowerMeter::read_register(uint8_t reg, uint16_t& value) {
    uint8_t data[2];
    esp_err_t ret = i2c_master_write_read_device((i2c_port_num_t)i2c_port_,
                                                  i2c_addr_, &reg, 1, data, 2,
                                                  100 / portTICK_PERIOD_MS);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to read register 0x%02X: %s", reg, esp_err_to_name(ret));
        return false;
    }
    value = ((uint16_t)data[0] << 8) | data[1];
    return true;
}

void PowerMeter::read_power(float& voltage_v, float& current_a, float& power_w, 
                            float& power_factor, bool& valid) {
    valid = false;
    voltage_v = 0.0f;
    current_a = 0.0f;
    power_w = 0.0f;
    power_factor = 1.0f;
    
    uint16_t raw_bus_voltage, raw_current, raw_power;
    
    if (!read_register(REG_BUS_VOLTAGE, raw_bus_voltage)) {
        ESP_LOGW(TAG, "Failed to read bus voltage");
        return;
    }
    
    if (!read_register(REG_CURRENT, raw_current)) {
        ESP_LOGW(TAG, "Failed to read current");
        return;
    }
    
    if (!read_register(REG_POWER, raw_power)) {
        ESP_LOGW(TAG, "Failed to read power");
        return;
    }
    
    // Parse bus voltage (bits 15-3, LSB = 4mV)
    voltage_v = (raw_bus_voltage >> 3) * 0.004f;
    
    // Parse current (16-bit signed, LSB = current_lsb_)
    int16_t current_raw = (int16_t)raw_current;
    current_a = current_raw * current_lsb_;
    
    // Parse power (16-bit unsigned, LSB = power_lsb_)
    power_w = raw_power * power_lsb_;
    
    // Calculate power factor (assuming unity if voltage and current present)
    if (voltage_v > 0.5f && current_a > 0.05f) {
        power_factor = power_w / (voltage_v * fabs(current_a));
        if (power_factor > 1.0f) power_factor = 1.0f;  // Clamp to 1.0
    }
    
    valid = (voltage_v > 0.5f) || (current_a > 0.05f);
    
    if (valid) {
        ESP_LOGI(TAG, "Voltage: %.2fV | Current: %.3fA | Power: %.2fW | PF: %.3f",
                 voltage_v, current_a, power_w, power_factor);
    }
}

void PowerMeter::read_harmonic_content(float& thd_percent, bool& valid) {
    valid = false;
    thd_percent = 0.0f;
    
    // Note: Basic INA219 doesn't have built-in harmonic analysis
    // This is a placeholder for systems with harmonic-capable sensors
    // In real implementation, would use FFT on sampled waveforms or
    // use devices like INA3221 or dedicated harmonic analyzers
    
    ESP_LOGW(TAG, "Harmonic analysis not available on basic INA219");
    thd_percent = 5.0f;  // Default low THD estimate
    valid = true;
}

void PowerMeter::set_config(uint16_t voltage_range, uint8_t adc_resolution) {
    uint16_t config = (voltage_range == 32) ? INA219_CONFIG_BVOLTAGERANGE_32V : 0;
    config |= INA219_CONFIG_GAIN_8_320MV;
    config |= (adc_resolution == 12) ? INA219_CONFIG_BADCRES_12BIT : 0;
    config |= INA219_CONFIG_SADCRES_12BIT_1S_532US;
    config |= INA219_CONFIG_MODE_SANDBVOLT_CONTINUOUS;
    
    write_register(REG_CONFIG, config);
}
