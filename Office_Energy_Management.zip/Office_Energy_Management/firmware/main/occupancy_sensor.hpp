#pragma once

#include <cstdint>
#include <cstddef>

/**
 * @brief Occupancy Sensor Fusion Driver
 * 
 * Combines PIR (motion), CO2 level, and acoustic patterns
 * to provide multi-modal occupancy detection
 */
class OccupancySensor {
public:
    /**
     * @brief Initialize occupancy sensor
     * @param pir_pin GPIO pin for PIR motion sensor
     * @param adc_channel ADC channel for CO2 sensor (0-7)
     */
    OccupancySensor(int pir_pin, int adc_channel);
    
    /**
     * @brief Initialize the sensor hardware
     * @return true if successful
     */
    bool init();
    
    /**
     * @brief Read occupancy state
     * @param occupancy_level Output: Occupancy level (0.0-1.0)
     *        0.0 = empty, 0.33 = minimal, 0.67 = partial, 1.0 = full
     * @param motion_detected Output: PIR motion detected
     * @param co2_ppm Output: CO2 level in ppm
     * @param valid Output: Measurement validity flag
     */
    void read_occupancy(float& occupancy_level, bool& motion_detected, 
                       float& co2_ppm, bool& valid);
    
    /**
     * @brief Reset occupancy tracking (for new room)
     */
    void reset_baseline();

private:
    int pir_pin_;
    int adc_channel_;
    
    // Occupancy state tracking
    uint32_t motion_time_;      // Last motion detection time
    uint32_t motion_history_;   // 32-bit motion history (recent 32 samples)
    uint16_t co2_baseline_;     // Baseline CO2 level (outdoor ~410 ppm)
    float occupancy_smoothed_;  // EMA-filtered occupancy
    
    // ADC reading
    uint16_t read_adc();
    
    // Helper functions
    float calculate_occupancy();
    bool detect_recent_motion();
};
