#include "occupancy_sensor.hpp"
#include "esp_log.h"
#include "driver/gpio.h"
#include "esp_adc/adc_oneshot.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char* TAG = "OccupancySensor";

static adc_oneshot_unit_handle_t adc_handle = nullptr;

OccupancySensor::OccupancySensor(int pir_pin, int adc_channel)
    : pir_pin_(pir_pin), adc_channel_(adc_channel),
      motion_time_(0), motion_history_(0), co2_baseline_(410),
      occupancy_smoothed_(0.0f) {}

bool OccupancySensor::init() {
    ESP_LOGI(TAG, "Initializing occupancy sensor on GPIO %d, ADC ch %d", 
             pir_pin_, adc_channel_);
    
    // Configure PIR GPIO as input
    gpio_config_t gpio_conf = {
        .pin_bit_mask = (1ULL << pir_pin_),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    
    if (gpio_config(&gpio_conf) != ESP_OK) {
        ESP_LOGE(TAG, "Failed to configure PIR GPIO");
        return false;
    }
    
    // Configure ADC for CO2 sensor
    adc_oneshot_unit_init_cfg_t init_config = {
        .unit_id = ADC_UNIT_1,
        .ulp_mode = ADC_ULP_MODE_DISABLE,
    };
    
    if (adc_oneshot_new_unit(&init_config, &adc_handle) != ESP_OK) {
        ESP_LOGE(TAG, "Failed to initialize ADC");
        return false;
    }
    
    // Configure ADC channel
    adc_oneshot_chan_cfg_t chan_config = {
        .bitwidth = ADC_BITWIDTH_12,
        .atten = ADC_ATTEN_DB_11,
    };
    
    if (adc_oneshot_config_channel(adc_handle, (adc_channel_t)adc_channel_, &chan_config) != ESP_OK) {
        ESP_LOGE(TAG, "Failed to configure ADC channel");
        return false;
    }
    
    reset_baseline();
    ESP_LOGI(TAG, "Occupancy sensor initialized");
    return true;
}

uint16_t OccupancySensor::read_adc() {
    int adc_reading = 0;
    if (adc_oneshot_read(adc_handle, (adc_channel_t)adc_channel_, &adc_reading) != ESP_OK) {
        ESP_LOGW(TAG, "Failed to read ADC");
        return 0;
    }
    return (uint16_t)adc_reading;
}

bool OccupancySensor::detect_recent_motion() {
    // Check if motion detected in last 30 seconds
    uint32_t now = xTaskGetTickCount() * portTICK_PERIOD_MS;
    
    if (gpio_get_level((gpio_num_t)pir_pin_)) {
        motion_time_ = now;
        motion_history_ = (motion_history_ << 1) | 1;  // Shift in 1 bit
    } else {
        motion_history_ = motion_history_ << 1;  // Shift in 0 bit
    }
    
    // If any motion in last 5 samples (each ~200ms = 1 sec window)
    return (motion_history_ & 0x1F) != 0;
}

float OccupancySensor::calculate_occupancy() {
    // Multi-modal occupancy fusion
    float occupancy = 0.0f;
    
    // PIR motion: 0.4 weight
    if (detect_recent_motion()) {
        occupancy += 0.4f;
    }
    
    // CO2 level: 0.6 weight
    // Baseline ~410 ppm empty room
    // Occupied: 600-1000 ppm
    // Very occupied: >1000 ppm
    uint16_t co2_raw = read_adc();
    float co2_ppm = (co2_raw / 4095.0f) * 2000.0f + 400.0f;  // Scale to 400-2400 ppm range
    
    if (co2_ppm > 500) {
        float co2_occupancy = (co2_ppm - 500.0f) / 1000.0f;
        occupancy += 0.6f * fmin(1.0f, co2_occupancy);
    }
    
    // Clamp occupancy
    occupancy = fmin(1.0f, fmax(0.0f, occupancy));
    
    return occupancy;
}

void OccupancySensor::read_occupancy(float& occupancy_level, bool& motion_detected, 
                                     float& co2_ppm, bool& valid) {
    valid = false;
    occupancy_level = 0.0f;
    motion_detected = false;
    co2_ppm = 410.0f;
    
    // Read motion
    motion_detected = gpio_get_level((gpio_num_t)pir_pin_);
    
    // Read CO2 level
    uint16_t co2_raw = read_adc();
    co2_ppm = (co2_raw / 4095.0f) * 2000.0f + 400.0f;  // Scale to 400-2400 ppm
    
    // Calculate occupancy with EMA smoothing (alpha = 0.2)
    float raw_occupancy = calculate_occupancy();
    occupancy_smoothed_ = 0.2f * raw_occupancy + 0.8f * occupancy_smoothed_;
    occupancy_level = occupancy_smoothed_;
    
    valid = true;
    
    ESP_LOGI(TAG, "Occupancy: %.2f | Motion: %s | CO2: %.0f ppm",
             occupancy_level, motion_detected ? "YES" : "NO", co2_ppm);
}

void OccupancySensor::reset_baseline() {
    motion_time_ = 0;
    motion_history_ = 0;
    occupancy_smoothed_ = 0.0f;
    ESP_LOGI(TAG, "Occupancy baseline reset");
}
