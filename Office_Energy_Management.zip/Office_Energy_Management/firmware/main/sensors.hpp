#pragma once

#include <array>
#include <cstdint>

#include "esp_err.h"

struct SensorReadings {
    float occupancy_score;        // 0-1, probability of room occupancy
    float motion_detection;       // Motion sensor reading (0-1)
    float light_level;            // Ambient light level (0-1, 0=dark, 1=bright)
    float temperature;            // Room temperature (°C)
    float energy_consumption;     // Current energy consumption (W)
    float appliance_state;        // Aggregate appliance state (0-1)
    bool occupancy_valid;
    bool motion_valid;
    bool light_valid;
};

class SensorHub {
public:
    esp_err_t init();
    esp_err_t sample(SensorReadings &out_readings);

private:
    esp_err_t init_pir_sensor();
    esp_err_t init_light_sensor();
    esp_err_t init_temperature_sensor();
    esp_err_t init_energy_monitor();

    esp_err_t read_occupancy(float &score, bool &valid);
    esp_err_t read_motion(float &motion, bool &valid);
    esp_err_t read_light(float &level, bool &valid);
    esp_err_t read_temperature(float &temp, bool &valid);
    esp_err_t read_energy(float &consumption, float &appliance_state, bool &valid);
    
    float clamp01(float value) const;
};
