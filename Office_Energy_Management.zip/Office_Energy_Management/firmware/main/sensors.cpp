#include "sensors.hpp"

#include <cmath>
#include <cstring>

#include "driver/adc.h"
#include "driver/gpio.h"
#include "esp_log.h"

#ifdef CONFIG_ENERGY_SENSOR_SIMULATION
#include "simulation.hpp"
#endif

namespace {
constexpr char kTag[] = "EnergySensorHub";

constexpr gpio_num_t kPirPin = GPIO_NUM_4;      // PIR motion sensor
constexpr gpio_num_t kLightSensorPin = GPIO_NUM_2;  // Light sensor (ADC)
constexpr gpio_num_t kTempSensorPin = GPIO_NUM_1;   // Temperature sensor (ADC)

#ifdef CONFIG_ENERGY_SENSOR_SIMULATION
static SensorSimulator simulator;
#endif
}  // namespace

esp_err_t SensorHub::init() {
#ifdef CONFIG_ENERGY_SENSOR_SIMULATION
    return simulator.init();
#else
    ESP_RETURN_ON_ERROR(init_pir_sensor(), kTag, "PIR init failed");
    ESP_RETURN_ON_ERROR(init_light_sensor(), kTag, "Light sensor init failed");
    ESP_RETURN_ON_ERROR(init_temperature_sensor(), kTag, "Temperature sensor init failed");
    ESP_RETURN_ON_ERROR(init_energy_monitor(), kTag, "Energy monitor init failed");
    return ESP_OK;
#endif
}

esp_err_t SensorHub::sample(SensorReadings &out_readings) {
    memset(&out_readings, 0, sizeof(out_readings));
#ifdef CONFIG_ENERGY_SENSOR_SIMULATION
    return simulator.sample(out_readings);
#else
    ESP_RETURN_ON_ERROR(read_motion(out_readings.motion_detection,
                                     out_readings.motion_valid),
                        kTag, "Motion read failed");
    ESP_RETURN_ON_ERROR(read_light(out_readings.light_level,
                                    out_readings.light_valid),
                        kTag, "Light read failed");
    ESP_RETURN_ON_ERROR(read_temperature(out_readings.temperature,
                                          out_readings.light_valid),
                        kTag, "Temperature read failed");
    ESP_RETURN_ON_ERROR(read_energy(out_readings.energy_consumption,
                                    out_readings.appliance_state,
                                    out_readings.light_valid),
                        kTag, "Energy read failed");
    ESP_RETURN_ON_ERROR(read_occupancy(out_readings.occupancy_score,
                                       out_readings.occupancy_valid),
                        kTag, "Occupancy read failed");
    return ESP_OK;
#endif
}

esp_err_t SensorHub::init_pir_sensor() {
    gpio_config_t cfg{};
    cfg.mode = GPIO_MODE_INPUT;
    cfg.pull_up_en = GPIO_PULLUP_DISABLE;
    cfg.pin_bit_mask = (1ULL << kPirPin);
    ESP_RETURN_ON_ERROR(gpio_config(&cfg), kTag, "PIR gpio config");
    return ESP_OK;
}

esp_err_t SensorHub::init_light_sensor() {
    // ADC configuration for light sensor
    return ESP_OK;
}

esp_err_t SensorHub::init_temperature_sensor() {
    // ADC configuration for temperature sensor
    return ESP_OK;
}

esp_err_t SensorHub::init_energy_monitor() {
    // I2C/SPI configuration for energy monitoring IC
    return ESP_OK;
}

esp_err_t SensorHub::read_occupancy(float &score, bool &valid) {
    // Combine motion, light, and temperature to infer occupancy
    // Placeholder: actual implementation would fuse multiple sensor inputs
    static float base_occupancy = 0.0f;
    base_occupancy += 0.02f;
    if (base_occupancy > 1.0f) base_occupancy = 0.0f;
    score = base_occupancy;
    valid = true;
    return ESP_OK;
}

esp_err_t SensorHub::read_motion(float &motion, bool &valid) {
    // Read PIR sensor
    const int level = gpio_get_level(kPirPin);
    motion = level ? 1.0f : 0.0f;
    valid = true;
    return ESP_OK;
}

esp_err_t SensorHub::read_light(float &level, bool &valid) {
    // Read light sensor via ADC
    // Placeholder: actual implementation would read ADC and normalize
    static float fake = 0.5f;
    fake += 0.01f;
    if (fake > 1.0f) fake = 0.0f;
    level = fake;
    valid = true;
    return ESP_OK;
}

esp_err_t SensorHub::read_temperature(float &temp, bool &valid) {
    // Read temperature sensor via ADC
    // Placeholder: actual implementation would read ADC and convert to °C
    static float fake = 22.0f;
    fake += 0.1f;
    if (fake > 25.0f) fake = 20.0f;
    temp = fake;
    valid = true;
    return ESP_OK;
}

esp_err_t SensorHub::read_energy(float &consumption, float &appliance_state, bool &valid) {
    // Read energy monitoring IC
    // Placeholder: actual implementation would read power consumption
    consumption = 150.0f;  // Watts
    appliance_state = 0.6f;
    valid = true;
    return ESP_OK;
}

float SensorHub::clamp01(float value) const {
    if (value < 0.0f) return 0.0f;
    if (value > 1.0f) return 1.0f;
    return value;
}
