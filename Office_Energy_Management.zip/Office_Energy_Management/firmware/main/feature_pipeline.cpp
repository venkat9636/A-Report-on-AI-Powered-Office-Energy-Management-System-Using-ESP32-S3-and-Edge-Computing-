#include "feature_pipeline.hpp"

#include <algorithm>
#include <cmath>

void FeaturePipeline::build(const SensorReadings &readings,
                            FeatureVector &out_features) {
    out_features.fill(0.0f);
    size_t idx = 0;
    
    // Primary occupancy and energy features
    out_features[idx++] = normalize(readings.occupancy_score, 0.0f, 1.0f);
    out_features[idx++] = normalize(readings.motion_detection, 0.0f, 1.0f);
    out_features[idx++] = normalize(readings.light_level, 0.0f, 1.0f);
    out_features[idx++] = normalize(readings.temperature, 15.0f, 30.0f);
    out_features[idx++] = normalize(readings.energy_consumption, 0.0f, 500.0f);
    out_features[idx++] = normalize(readings.appliance_state, 0.0f, 1.0f);
    
    // Validity flags
    out_features[idx++] = readings.occupancy_valid ? 1.0f : 0.0f;
    out_features[idx++] = readings.motion_valid ? 1.0f : 0.0f;
    out_features[idx++] = readings.light_valid ? 1.0f : 0.0f;
    
    // Rolling statistics for trend analysis
    static float occupancy_ema = 0.0f;
    static float energy_ema = 100.0f;
    static float light_ema = 0.5f;
    
    occupancy_ema = 0.9f * occupancy_ema + 0.1f * readings.occupancy_score;
    energy_ema = 0.85f * energy_ema + 0.15f * readings.energy_consumption;
    light_ema = 0.9f * light_ema + 0.1f * readings.light_level;
    
    out_features[idx++] = normalize(occupancy_ema, 0.0f, 1.0f);
    out_features[idx++] = normalize(energy_ema, 0.0f, 500.0f);
    out_features[idx++] = normalize(light_ema, 0.0f, 1.0f);
    
    // Derived features: energy efficiency indicators
    const float efficiency_score = (1.0f - readings.occupancy_score) * (1.0f - readings.light_level);
    out_features[idx++] = normalize(efficiency_score, 0.0f, 1.0f);
    
    // Occupancy-light mismatch (lights on when empty = waste)
    const float mismatch = readings.light_level * (1.0f - readings.occupancy_score);
    out_features[idx++] = normalize(mismatch, 0.0f, 1.0f);
    
    // Pad remaining slots
    while (idx < out_features.size()) {
        out_features[idx++] = efficiency_score;
    }
}

float FeaturePipeline::normalize(float value, float min, float max) const {
    const float clipped = std::clamp(value, min, max);
    return (clipped - min) / (max - min + 1e-3f);
}
