#pragma once

#include "ai_processor.hpp"
#include "sensors.hpp"

enum class AlertLevel {
    kOptimal = 0,        // Optimal energy usage
    kEfficient = 1,      // Efficient operation
    kWarning = 2,        // Energy waste detected
    kCritical = 3,      // Significant waste or anomaly
};

class AlertManager {
public:
    esp_err_t init();
    void update(const SensorReadings &readings,
                const InferenceResult &result);

private:
    void drive_led(AlertLevel level);
    void drive_buzzer(AlertLevel level);
    AlertLevel last_alert_ = AlertLevel::kNormal;
};



