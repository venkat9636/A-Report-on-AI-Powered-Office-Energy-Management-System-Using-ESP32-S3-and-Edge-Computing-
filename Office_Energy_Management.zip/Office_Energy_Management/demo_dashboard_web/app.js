const occEl = document.getElementById("occ-value");
const motionEl = document.getElementById("motion-value");
const lightEl = document.getElementById("light-value");
const tempEl = document.getElementById("temp-value");
const totalEnergyEl = document.getElementById("total-energy-value");
const hvacEl = document.getElementById("hvac-value");
const lightingEl = document.getElementById("lighting-value");
const stateEl = document.getElementById("state-value");
const headerEnergyEl = document.getElementById("header-energy");
const logEl = document.getElementById("event-log");

const barMap = {
  optimal: document.getElementById("bar-optimal"),
  efficient: document.getElementById("bar-efficient"),
  warning: document.getElementById("bar-warning"),
  critical: document.getElementById("bar-critical"),
};

const pctMap = {
  optimal: document.getElementById("pct-optimal"),
  efficient: document.getElementById("pct-efficient"),
  warning: document.getElementById("pct-warning"),
  critical: document.getElementById("pct-critical"),
};

// Chart instances
let charts = {
  occupancy: null,
  motion: null,
  light: null,
  temperature: null,
  hvac: null,
  lighting: null,
  totalEnergy: null,
  state: null
};

// Chart data storage
const MAX_DATA_POINTS = 50;
let chartData = {
  occupancy: { labels: [], values: [] },
  motion: { labels: [], values: [] },
  light: { labels: [], values: [] },
  temperature: { labels: [], values: [] },
  hvac: { labels: [], values: [] },
  lighting: { labels: [], values: [] },
  totalEnergy: { labels: [], values: [] },
  state: { labels: [], values: [] }
};

// TensorFlow.js model
let mlModel = null;
let modelLoaded = false;
let modelLoading = false;

let time = 0;
let occupancyState = 0.0;
let motionState = 0.0;

function clamp(val, min, max) {
  return Math.min(max, Math.max(min, val));
}

function log(message) {
  if (!logEl) return;
  const item = document.createElement("li");
  const timestamp = new Date().toLocaleTimeString();
  item.textContent = `[${timestamp}] ${message}`;
  logEl.prepend(item);
  while (logEl.children.length > 8) {
    logEl.removeChild(logEl.lastChild);
  }
}

function simulateSensors() {
  time += 0.2;
  
  // Simulate occupancy patterns
  if (Math.random() > 0.96) {
    occupancyState = clamp(occupancyState + 0.4, 0, 1);
    motionState = 0.8;
  } else if (Math.random() > 0.98 && occupancyState > 0.3) {
    occupancyState = clamp(occupancyState - 0.5, 0, 1);
    motionState = 0.2;
  } else {
    occupancyState *= 0.995;
    motionState *= 0.95;
  }
  
  const occupancy = clamp(occupancyState + Math.random() * 0.1, 0, 1);
  const motion = clamp(motionState + Math.random() * 0.15, 0, 1);
  const baseLight = 0.3;
  const lightLevel = clamp(baseLight + occupancyState * 0.6 + Math.random() * 0.1, 0, 1);
  const temperature = 22.0 + occupancyState * 2.0 + Math.sin(time * 0.01) * 1.0 + Math.random() * 0.5;
  const hvacConsumption = 150.0 + occupancyState * 150.0 + Math.random() * 30.0;
  const lightingConsumption = 50.0 + lightLevel * 150.0 + Math.random() * 20.0;
  const energyConsumption = hvacConsumption + lightingConsumption;
  const applianceState = clamp(occupancyState * 0.8 + lightLevel * 0.5, 0, 1);
  
  return {
    occupancy,
    motion,
    lightLevel,
    temperature,
    energyConsumption,
    hvacConsumption,
    lightingConsumption,
    applianceState,
  };
}

// Load ML model - try backend first, then TensorFlow.js, then heuristic
async function loadMLModel() {
  if (modelLoaded || modelLoading) return;
  modelLoading = true;
  
  // First, check if ML backend is available (preferred - uses real .tflite model)
  try {
    const response = await fetch('http://localhost:5000/health', { method: 'GET', mode: 'cors' });
    if (response.ok) {
      const healthData = await response.json();
      if (healthData.models_loaded.includes('office_energy_system')) {
        modelLoaded = true;
        modelLoading = false;
        log("✓ ML Backend server available - using real TinyML models");
        return true;
      }
    }
  } catch (error) {
    // Backend not available, continue to TensorFlow.js
  }
  
  // Fallback to TensorFlow.js (only if backend is not available)
  // Note: TensorFlow.js models may not exist - this is expected if using backend
  try {
    const modelPath = '../ml/training/artifacts/tfjs_model/model.json';
    mlModel = await tf.loadLayersModel(modelPath);
    modelLoaded = true;
    modelLoading = false;
    log("✓ TensorFlow.js model loaded successfully - using real ML inference");
    return true;
  } catch (error) {
    // TensorFlow.js model not available - this is OK if using backend
    // Only log as warning if backend was also unavailable
    if (error.message && error.message.includes('404')) {
      // Suppress 404 errors - TensorFlow.js models are optional when using backend
      console.log("TensorFlow.js model not found (this is OK if ML backend is running)");
    } else {
      console.warn("Could not load TensorFlow.js model, using heuristic fallback:", error);
    }
    modelLoading = false;
    return false;
  }
}

// Run inference - uses real model if available, otherwise heuristic
async function runTinyModel(features) {
  // Normalize features (same as firmware)
  const occ = clamp(features.occupancy, 0, 1);
  const motion = clamp(features.motion, 0, 1);
  const light = clamp(features.lightLevel, 0, 1);
  const temp = clamp((features.temperature - 15) / 15, 0, 1);
  const energy = clamp(features.energyConsumption / 500, 0, 1);
  const appliance = clamp(features.applianceState, 0, 1);
  
  // Build 16-feature vector
  const featureVector = [
    occ, motion, light, temp, energy, appliance,
    1.0, 1.0, 1.0, // validity flags
    occ * 0.9, energy * 0.85, light * 0.9, // EMAs
    (1 - occ) * (1 - light), light * (1 - occ), (1 - occ) * (1 - light), occ
  ].slice(0, 16);
  
  // Try ML backend first (preferred - uses real .tflite model)
  if (modelLoaded) {
    try {
      const response = await fetch('http://localhost:5000/infer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        mode: 'cors',
        body: JSON.stringify({
          project: 'office_energy_system',
          features: featureVector
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        return data.probabilities;
      }
    } catch (error) {
      // Backend unavailable, try TensorFlow.js
    }
  }
  
  // Fallback to TensorFlow.js model
  if (modelLoaded && mlModel) {
    try {
      const input = tf.tensor2d([featureVector], [1, 16]);
      const prediction = mlModel.predict(input);
      const probs = await prediction.data();
      input.dispose();
      prediction.dispose();
      return Array.from(probs);
    } catch (error) {
      console.error("Model inference error:", error);
    }
  }
  
  // Heuristic fallback
  const mismatch = light * (1 - occ);
  const efficiency = (1 - occ) * (1 - light);
  
  const logits = [
    1.5 - mismatch * 1.5 - energy * 0.5 + efficiency * 0.8,
    0.5 + occ * 0.5 - mismatch * 0.5 - energy * 0.3,
    mismatch * 1.0 + energy * 0.8 - efficiency * 0.5,
    mismatch * 1.5 + energy * 1.2 - efficiency * 1.0,
  ];
  
  const exp = logits.map((l) => Math.exp(l));
  const sum = exp.reduce((a, b) => a + b, 0);
  return exp.map((v) => v / sum);
}

function updateBars(probs) {
  const labels = ["optimal", "efficient", "warning", "critical"];
  labels.forEach((label, idx) => {
    const bar = barMap[label];
    if (bar) {
      bar.style.width = `${probs[idx] * 100}%`;
    }
    const pct = pctMap[label];
    if (pct) {
      pct.textContent = `${(probs[idx] * 100).toFixed(0)}%`;
    }
  });
}

async function updateUI(readings, probs, label) {
  if (occEl) occEl.textContent = (readings.occupancy * 100).toFixed(1) + "%";
  if (motionEl) motionEl.textContent = (readings.motion * 100).toFixed(1) + "%";
  if (lightEl) lightEl.textContent = (readings.lightLevel * 100).toFixed(1) + "%";
  if (tempEl) tempEl.textContent = readings.temperature.toFixed(1);
  if (totalEnergyEl) totalEnergyEl.textContent = readings.energyConsumption.toFixed(0);
  if (hvacEl) hvacEl.textContent = readings.hvacConsumption.toFixed(0);
  if (lightingEl) lightingEl.textContent = readings.lightingConsumption.toFixed(0);
  if (headerEnergyEl) headerEnergyEl.textContent = readings.energyConsumption.toFixed(0) + " W";
  
  const stateNames = ["Optimal", "Efficient", "Warning", "Critical"];
  const stateIdx = probs.indexOf(Math.max(...probs));
  if (stateEl) stateEl.textContent = stateNames[stateIdx];
  
  updateBars(probs);
  updateCharts(readings, stateIdx);
  log(`State: ${label} | probs ${probs.map((p) => p.toFixed(2)).join(", ")}`);
}

function getLabel(probs) {
  const idx = probs.indexOf(Math.max(...probs));
  const labels = ["Optimal", "Efficient", "Warning", "Critical"];
  return labels[idx];
}

// Initialize charts
function initializeCharts() {
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false }, tooltip: { mode: 'index', intersect: false } },
    scales: {
      x: { grid: { color: 'rgba(255, 255, 255, 0.1)' }, ticks: { color: 'rgba(255, 255, 255, 0.7)', maxTicksLimit: 10 } },
      y: { grid: { color: 'rgba(255, 255, 255, 0.1)' }, ticks: { color: 'rgba(255, 255, 255, 0.7)' } }
    },
    elements: { point: { radius: 2, hoverRadius: 4 }, line: { tension: 0.4, borderWidth: 2 } }
  };

  try {
    const occupancyCanvas = document.getElementById('chart-occupancy');
    if (occupancyCanvas) {
      charts.occupancy = new Chart(occupancyCanvas, {
        type: 'line', data: { labels: [], datasets: [{ data: [], borderColor: '#4CAF50', backgroundColor: 'rgba(76, 175, 80, 0.1)', fill: true }] },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 0, max: 1 } } }
      });
    }

    const motionCanvas = document.getElementById('chart-motion');
    if (motionCanvas) {
      charts.motion = new Chart(motionCanvas, {
        type: 'line', data: { labels: [], datasets: [{ data: [], borderColor: '#2196F3', backgroundColor: 'rgba(33, 150, 243, 0.1)', fill: true }] },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 0, max: 1 } } }
      });
    }

    const lightCanvas = document.getElementById('chart-light');
    if (lightCanvas) {
      charts.light = new Chart(lightCanvas, {
        type: 'line', data: { labels: [], datasets: [{ data: [], borderColor: '#FFC107', backgroundColor: 'rgba(255, 193, 7, 0.1)', fill: true }] },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 0, max: 1 } } }
      });
    }

    const tempCanvas = document.getElementById('chart-temperature');
    if (tempCanvas) {
      charts.temperature = new Chart(tempCanvas, {
        type: 'line', data: { labels: [], datasets: [{ data: [], borderColor: '#FF5722', backgroundColor: 'rgba(255, 87, 34, 0.1)', fill: true }] },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 15, max: 30 } } }
      });
    }

    const hvacCanvas = document.getElementById('chart-hvac');
    if (hvacCanvas) {
      charts.hvac = new Chart(hvacCanvas, {
        type: 'line', data: { labels: [], datasets: [{ data: [], borderColor: '#00D4FF', backgroundColor: 'rgba(0, 212, 255, 0.1)', fill: true }] },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 0, max: 400 } } }
      });
    }

    const lightingCanvas = document.getElementById('chart-lighting');
    if (lightingCanvas) {
      charts.lighting = new Chart(lightingCanvas, {
        type: 'line', data: { labels: [], datasets: [{ data: [], borderColor: '#FFD700', backgroundColor: 'rgba(255, 215, 0, 0.1)', fill: true }] },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 0, max: 300 } } }
      });
    }

    const totalEnergyCanvas = document.getElementById('chart-total-energy');
    if (totalEnergyCanvas) {
      charts.totalEnergy = new Chart(totalEnergyCanvas, {
        type: 'line', data: { labels: [], datasets: [{ data: [], borderColor: '#9C27B0', backgroundColor: 'rgba(156, 39, 176, 0.1)', fill: true }] },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 0, max: 800 } } }
      });
    }

    const stateCanvas = document.getElementById('chart-state');
    if (stateCanvas) {
      charts.state = new Chart(stateCanvas, {
        type: 'line', data: { labels: [], datasets: [{ data: [], borderColor: '#F44336', backgroundColor: 'rgba(244, 67, 54, 0.1)', fill: true, stepped: 'after' }] },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: -0.5, max: 3.5, ticks: { stepSize: 1, callback: v => ['Optimal', 'Efficient', 'Warning', 'Critical'][v] || '' } } } }
      });
    }
  } catch (error) {
    console.error("Failed to create chart:", error);
  }
}

function updateCharts(readings, stateIdx) {
  const now = new Date().toLocaleTimeString();
  
  function addData(chartName, value) {
    const data = chartData[chartName];
    if (data) {
      data.labels.push(now);
      data.values.push(value);
      if (data.labels.length > MAX_DATA_POINTS) { data.labels.shift(); data.values.shift(); }
    }
  }

  addData('occupancy', readings.occupancy);
  addData('motion', readings.motion);
  addData('light', readings.lightLevel);
  addData('temperature', readings.temperature);
  addData('hvac', readings.hvacConsumption);
  addData('lighting', readings.lightingConsumption);
  addData('totalEnergy', readings.energyConsumption);
  addData('state', stateIdx);

  Object.keys(charts).forEach(key => {
    if (charts[key] && chartData[key]) {
      charts[key].data.labels = chartData[key].labels;
      charts[key].data.datasets[0].data = chartData[key].values;
      charts[key].update('none');
    }
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeCharts);
} else {
  initializeCharts();
}

// Initialize
(async () => {
  await loadMLModel();
  log("System initialized. Monitoring occupancy and energy consumption...");
  
  setInterval(async () => {
    const readings = simulateSensors();
    const probs = await runTinyModel(readings);
    const label = getLabel(probs);
    await updateUI(readings, probs, label);
  }, 500);
})();
