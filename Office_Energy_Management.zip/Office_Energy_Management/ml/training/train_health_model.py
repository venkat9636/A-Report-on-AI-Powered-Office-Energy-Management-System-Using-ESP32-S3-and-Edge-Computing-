#!/usr/bin/env python3
"""
Train TinyML model for Smart Energy Management System
Classifies energy efficiency states: Optimal, Efficient, Warning, Critical
"""

import numpy as np
import tensorflow as tf
from dataclasses import dataclass
from pathlib import Path

NUM_CLASSES = 4
NUM_FEATURES = 16
OUTPUT_DIR = Path(__file__).parent / "artifacts"  # Changed to ml/training/artifacts
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

@dataclass
class Dataset:
    x: np.ndarray
    y: np.ndarray

def generate_dataset(
    samples: int = 4000,
    seed: int | None = None,
) -> tuple[Dataset, Dataset]:
    rng = np.random.default_rng(seed)
    
    # Base signals for energy management
    occupancy = rng.beta(2, 3, samples)  # Most time empty, some occupancy
    motion = occupancy * rng.uniform(0.7, 1.0, samples)  # Motion correlates with occupancy
    light_level = rng.beta(3, 2, samples)  # Light levels
    temperature = rng.normal(22, 2, samples)  # Room temperature
    energy_consumption = 50 + occupancy * 200 + light_level * 100 + rng.normal(0, 20, samples)
    appliance_state = occupancy * 0.8 + light_level * 0.5
    
    # State logic for energy efficiency
    labels = np.zeros(samples, dtype=np.int32)
    
    # Optimal (0): Low occupancy, low energy, lights off when empty
    labels[(occupancy < 0.2) & (energy_consumption < 100) & (light_level < 0.3)] = 0
    
    # Efficient (1): Occupied, reasonable energy usage
    labels[(occupancy > 0.3) & (occupancy < 0.7) & (energy_consumption < 200) & (light_level < 0.8)] = 1
    
    # Warning (2): Energy waste detected (lights on when empty, high consumption)
    labels[((occupancy < 0.2) & (light_level > 0.5)) | (energy_consumption > 250)] = 2
    
    # Critical (3): Significant waste or anomaly
    labels[((occupancy < 0.1) & (light_level > 0.7)) | (energy_consumption > 350) | ((occupancy < 0.2) & (energy_consumption > 200))] = 3
    
    # Override: if already Optimal or Efficient, keep it
    optimal_mask = (occupancy < 0.2) & (energy_consumption < 100) & (light_level < 0.3)
    efficient_mask = (occupancy > 0.3) & (occupancy < 0.7) & (energy_consumption < 200) & (light_level < 0.8)
    labels[optimal_mask] = 0
    labels[efficient_mask & (labels != 0)] = 1
    
    features = np.stack(
        [
            occupancy,
            motion,
            light_level,
            temperature,
            energy_consumption,
            appliance_state,
            rng.uniform(0.8, 1.0, samples),  # occupancy_valid
            rng.uniform(0.8, 1.0, samples),  # motion_valid
            rng.uniform(0.8, 1.0, samples),  # light_valid
            # Rolling averages
            occupancy * 0.9 + rng.normal(0, 0.05, samples),  # occupancy_ema
            energy_consumption * 0.85 + rng.normal(0, 10, samples),  # energy_ema
            light_level * 0.9 + rng.normal(0, 0.05, samples),  # light_ema
            # Derived features
            (1 - occupancy) * (1 - light_level),  # efficiency_score
            light_level * (1 - occupancy),  # mismatch
            (1 - occupancy) * (1 - light_level),  # padding
            occupancy,  # Extra feature to make 16
        ],
        axis=-1,
    ).astype(np.float32)
    
    # Ensure exactly 16 features
    if features.shape[1] != NUM_FEATURES:
        features = features[:, :NUM_FEATURES]
    
    # Normalize features (matching FeaturePipeline)
    features[:, 0] = np.clip((features[:, 0] - 0.0) / 1.0, 0, 1)  # Occupancy (0-1)
    features[:, 1] = np.clip((features[:, 1] - 0.0) / 1.0, 0, 1)  # Motion (0-1)
    features[:, 2] = np.clip((features[:, 2] - 0.0) / 1.0, 0, 1)  # Light (0-1)
    features[:, 3] = np.clip((features[:, 3] - 15.0) / 15.0, 0, 1)  # Temperature (15-30)
    features[:, 4] = np.clip((features[:, 4] - 0.0) / 500.0, 0, 1)  # Energy (0-500W)
    features[:, 5] = np.clip((features[:, 5] - 0.0) / 1.0, 0, 1)  # Appliance state (0-1)
    features[:, 9] = np.clip((features[:, 9] - 0.0) / 1.0, 0, 1)  # occupancy_ema
    features[:, 10] = np.clip((features[:, 10] - 0.0) / 500.0, 0, 1)  # energy_ema
    features[:, 11] = np.clip((features[:, 11] - 0.0) / 1.0, 0, 1)  # light_ema
    
    # Split into train/test
    split_idx = int(samples * 0.8)
    train_dataset = Dataset(x=features[:split_idx], y=labels[:split_idx])
    test_dataset = Dataset(x=features[split_idx:], y=labels[split_idx:])
    return train_dataset, test_dataset

def build_model() -> tf.keras.Model:
    model = tf.keras.Sequential([
        tf.keras.layers.Dense(32, activation="relu", input_shape=(NUM_FEATURES,)),
        tf.keras.layers.Dropout(0.2),
        tf.keras.layers.Dense(16, activation="relu"),
        tf.keras.layers.Dropout(0.2),
        tf.keras.layers.Dense(NUM_CLASSES, activation="softmax"),
    ])
    return model

def train_model(train: Dataset, test: Dataset) -> tf.keras.Model:
    model = build_model()
    model.compile(
        optimizer="adam",
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    
    model.fit(
        train.x,
        train.y,
        epochs=50,
        batch_size=32,
        validation_data=(test.x, test.y),
        verbose=1,
    )
    
    test_loss, test_acc = model.evaluate(test.x, test.y, verbose=0)
    print(f"\nTest accuracy: {test_acc:.4f}")
    return model

def quantize_model(model: tf.keras.Model) -> bytes:
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    converter.target_spec.supported_types = [tf.int8]
    converter.inference_input_type = tf.int8
    converter.inference_output_type = tf.int8
    
    def representative_dataset():
        for i in range(100):
            yield [np.random.randn(1, NUM_FEATURES).astype(np.float32)]
    
    converter.representative_dataset = representative_dataset
    tflite_model = converter.convert()
    return tflite_model

def save_model_as_c_array(model_bytes: bytes, output_path: Path):
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        f.write("#pragma once\n\n")
        f.write("#include <cstdint>\n\n")
        f.write(f"extern const unsigned char g_energy_model_data[];\n")
        f.write(f"extern const int g_energy_model_data_len;\n")
    
    c_array_path = output_path.parent / "ai_model_data.cc"
    with open(c_array_path, "w") as f:
        f.write('#include "ai_model_data.h"\n\n')
        f.write("const unsigned char g_energy_model_data[] = {\n")
        for i, byte in enumerate(model_bytes):
            if i % 12 == 0:
                f.write("    ")
            f.write(f"0x{byte:02x},")
            if (i + 1) % 12 == 0:
                f.write("\n")
        if len(model_bytes) % 12 != 0:
            f.write("\n")
        f.write("};\n\n")
        f.write(f"const int g_energy_model_data_len = {len(model_bytes)};\n")

def main():
    print("Generating dataset...")
    train, test = generate_dataset(samples=4000, seed=42)
    print(f"Train: {len(train.x)} samples, Test: {len(test.x)} samples")
    
    print("\nTraining model...")
    model = train_model(train, test)
    
    print("\nQuantizing model...")
    quantized = quantize_model(model)
    
    print(f"\nQuantized model size: {len(quantized)} bytes")
    
    # Save .tflite file for ML backend server
    tflite_path = OUTPUT_DIR / "guardian_model.tflite"
    tflite_path.write_bytes(quantized)
    print(f"TFLite model saved to {tflite_path}")
    
    # Save Keras model
    keras_path = OUTPUT_DIR / "guardian_model.keras"
    model.save(keras_path)
    print(f"Keras model saved to {keras_path}")
    
    # Save C array for firmware (optional)
    firmware_artifacts_dir = Path(__file__).parent.parent.parent / "artifacts"
    firmware_artifacts_dir.mkdir(parents=True, exist_ok=True)
    header_path = firmware_artifacts_dir / "ai_model_data.h"
    save_model_as_c_array(quantized, header_path)
    print(f"C array saved to {header_path}")
    print(f"Copy ai_model_data.cc content to firmware/main/ai_model_data.cpp")

if __name__ == "__main__":
    main()
